// ==================================================
// ==           Par                                ==
// ==      Sandro Gazzo                            ==
// ==           Et                                 ==
// ==      Théo Dellouve                           ==
// ==================================================



#include <iostream>
#include <assert.h>
#include <math.h>
#include <string>
#include <fstream>
#include "matrice.h"
using namespace std;

class pendule 
{
    public:
    vecteur F1(vecteur&, double&); // la fonction du premier modèle
    vecteur F2(vecteur&,  double&); // la fonction du second modèle
    matrice DF1(vecteur&,  double&); // la matrice jacobienne du premier modèle
    matrice DF2(vecteur&, double&); // la matrice jacobienne du second modèle
    // vecteur phi_cc( int&,vecteur&,vecteur&, double&, double&); // AJOUT CC
    // vecteur newton_cc(int,vecteur&,double, double,double,const char*,const char*,const char*); // AJOUT CC
    vecteur phi1(vecteur&, vecteur&, double&, double&); //permet de calculer phi de newton du premier modèle
    matrice dphi1( vecteur&,  double&,  double&); //permet de calculer D_phi de newton du premier modèle
    vecteur newton1( vecteur&,  double&,  double&, double&); // pose le problème de newton et le résout pour une itération du premier modèle
    vecteur solvenew1 ( vecteur&, double&,  double&, double&, double&,const char*, const char*,const char*); // résout le problème de Newton du premier modèle
    vecteur phi2(vecteur&, vecteur&, double&, double&);//permet de calculer phi de newton du second modèle
    matrice dphi2( vecteur&,  double&,  double&); //permet de calculer D_phi de newton du second modèle
    vecteur newton2( vecteur&,  double&,  double&, double&);// pose le problème de newton et le résout pour une itération du second modèle
    vecteur solvenew2 ( vecteur&, double&,  double&, double&, double&,const char*, const char*,const char*); // résout le problème de Newton du premier modèle
    double pendule_amorti(double&,double&,double&,double&,const char*,const char*); //calcule la solution exacte
};

// Nous avons décidé de séparer les fonctions en 2 dans cette partie. En
// effet, suite à un problème de "choix" qui, pourtant, semblait plus joli 
// à écrire, nous n'obtenions pas les bons résultats. Nous avons donc
// découpé les fonctions en 2 pour éviter ce problème. Nous sommes conscients
// que ceci est moins élégant que ce que nous aurions voulu obtenir.

vecteur F1(vecteur& X,  double& lambda)
{
    vecteur k(2);
    double x=X(0);
    double y=X(1);
    k(0)=y;
    k(1)=-sin(x)-lambda*y;
    return k;
    }
 

vecteur F2(vecteur& X,  double& lambda)
   {
    vecteur k(2);
    double x=X(0);
    double y=X(1);
    k(0)=y;
    k(1)=-sin(x)-(pow(x,2)-lambda)*y;
    return k;
}


matrice DF1(vecteur& X,  double& lambda)
{
    matrice DF(2,2);
    double x=X(0);
    double y=X(1);
    DF[0](0)=0;
    DF[0](1)=1;
    DF[1](0)=-cos(x);
    DF[1](1)=-lambda;
    return DF;
}

matrice DF2(vecteur& X,  double& lambda)
{
    matrice DF(2,2);
    double x=X(0);
    double y=X(1);
    DF[0](0)=0;
    DF[0](1)=1;
    DF[1](0)=-cos(x)-2*x*y;
    DF[1](1)=pow(x,2)-lambda;
    return DF;
}


vecteur phi1( vecteur& Y, vecteur& X,  double& delta_t, double& lambda)
{
        return Y-(delta_t/2)*F1(Y,lambda)-X-(delta_t/2)*F1(X,lambda);
}

vecteur phi2( vecteur& Y, vecteur& X,  double& delta_t, double& lambda)
{
        
        return Y-(delta_t/2)*F2(Y,lambda)-X-(delta_t/2)*F2(X,lambda);

    
}

matrice dphi1( vecteur& Y, double& delta_t,  double& lambda)
{
    matrice I(2,2);
    I[0](0)=1;
    I[0](1)=0;
    I[1](1)=1;
    I[1](0)=0;
    return I-(delta_t/2)*DF1(Y,lambda);
}


matrice dphi2( vecteur& Y, double& delta_t,  double& lambda)
{
    matrice I(2,2);
    I[0](0)=1;
    I[0](1)=0;
    I[1](1)=1;
    I[1](0)=0;
    return I-(delta_t/2)*DF2(Y,lambda);
}


/*AJOUT C.CALGARO


vecteur phi_cc( int& choix, vecteur& Y, vecteur& uold,  double& delta_t, double& lambda) {
    vecteur S(2);
    if (choix=1){
        S(0) = Y(0) - uold(0) - (delta_t/2.)*(uold(1) + Y(1));
        S(1) = Y(1) - uold(1) + (delta_t/2.)*(sin(uold(0)) + lambda*uold(1) + sin(Y(0)) + lambda*Y(1));}
    else{
        S(0) = Y(0) - uold(0) - (delta_t/2.)*(uold(1) + Y(1));
        S(1) = Y(1) - uold(1) + (delta_t/2.)*(sin(uold(0)) - pow(uold(0),2)*uold(1) + lambda*uold(1) + sin(Y(0)) - pow(Y(0),2)*Y(1) + lambda*Y(1));}
    return S;}
    
    
    vecteur newton_cc(int choix,vecteur& Y,double T,double delta_t,double lambda,const char* theta,const char* thetaprime,const char* hamilton)
{
    vecteur V(2);
    matrice DPHI(2,2);
    vecteur PHI(2), Yk(2), Solu(2);
    matrice inverse(2,2);
    double det, erreur;
    double t=0, epsilon = pow(10,-10);
    int ite=int(T/delta_t)+1, kmax=10, k;
    ofstream file(theta);
    ofstream file1(thetaprime);
    ofstream file2(hamilton);

    Solu=Y; // c'est la solution initiale
    for(int n=0; n<ite;n++) // boucle iterations en temps
    {
        Yk=Solu; // initialisation de newton par la solution connue
        k=0;
        erreur=1;
        cout << " n = " << n << " Solu = " << Solu << endl;
        while (erreur>epsilon && k <kmax) // boucle de newton
        {
            cout << " k = " << k << " erreur = " << erreur << endl;
            DPHI=dphi(choix,Yk(0),Yk(1),delta_t,lambda); // jacobienne evaluee en Yk
            //cout << "DPHI=" << DPHI << endl << endl;
            det=1./((DPHI[0](0)*DPHI[1](1))-(DPHI[0](1)*DPHI[1](0)));
            //cout << "det = " << det << endl;
            inverse[0](0)=DPHI[1](1);
            inverse[1](1)=DPHI[0](0);
            inverse[1](0)=-DPHI[1](0);
            inverse[0](1)=-DPHI[0](1);
            DPHI=inverse*det; // inverse de la jacobienne evaluee en Y_k
            //cout << "inverse=" << inverse << endl;
        
            PHI=phi_cc(choix,Yk,Solu,delta_t,lambda); // phi qui depend de Yk et Solu
            // V(0)=Yk(0)-(DPHI*PHI)(0);
            // V(1)=Yk(1)-(DPHI*PHI)(1);
            V=Yk-(DPHI*PHI);
            erreur=PHI.norm_infini();
            k++;
            Yk=V; // c'est la nouvelle iteree de Newton
        }
        cout << "apres newton" << endl;
        Solu=Yk; // c'est la nouvelle solution
        file << t << " "<< Solu(0)<<endl;
        file1 << t << " " << Solu(1) << endl;
        file2 << t << " " << (pow(Solu(1),2)/2)-cos(Solu(0)) << endl;
        t=t+delta_t;
    }
    file.close();
    file1.close();
    file2.close();
    cout << "T = " << T << " delta_t = " << delta_t << " nb d'iter = " << ite << endl ;
    return V;
}*/


vecteur newton1(vecteur& X, double& delta_t,  double& lambda,  double& precision)
{
    // Initialisation
    vecteur Y(2);
    vecteur Z(2);
    matrice DPHI(2,2);
    vecteur PHI(2);
    vecteur e1(2);
    vecteur e2(2);
    double i=0;
    double i_max=15;

    PHI(0)=1; //Permet de commencer le while
    Y=X; // on continue avec Y pour ne pas modifier X
    
    // Choix du point pour commencer le gradient conjugué
    e1(0)=0.1; 
    e1(1)=0.1;

    while(PHI.norm_infini()>precision && i<i_max) 
    {
        DPHI=dphi1(Y,delta_t,lambda); // on stocke D_phi
        PHI=phi1(Y,X,delta_t,lambda); // on stocke phi
        e2=(-1)*PHI; // on multiplie par -1 phi pour pouvoir résoudre GC
        e1=DPHI.gc(e2,e1,1e-20,100); // on applique GC
        Z=Y+e1; // méthode de newton
        Y=Z; // on affecte Z à Y, ce qui augmentera la précision finale
        i=i+1;
    }
    return Y; 
}

vecteur solvenew1( vecteur& U0,  double& T,  double& delta_t, double& lambda, double& precision, const char* theta, const char* theta_prime, const char* hamilton)
{
    // Initialisation
    vecteur Y(2);
    double t=0;
    double ite=int(T/delta_t)+1;

    // Ouverture fichier 
    ofstream file(theta);
    ofstream file1(theta_prime);
    ofstream file2(hamilton);
    for (int n = 0; n < ite; n++) // le nombre d'itération pour réaliser newton
    {
        Y=U0; // on garde U0
        Y=newton1(Y,delta_t,lambda,precision); // On applique une itération de newton
        file << t << " "<< Y(0)<<endl;
        file1 << t << " " << Y(1) << endl;
        file2 << t << " " << (pow(Y(1),2)/2)-cos(Y(0)) << endl;
        U0=Y; // "U0 devient Y, i.e. U1"
        t=t+delta_t;
    }
    file.close();
    file1.close();
    file2.close();
    return Y;
}

vecteur newton2(vecteur& X, double& delta_t,  double& lambda,  double& precision)
{
    // Initialisation
    vecteur Y(2);
    vecteur Z(2);
    matrice DPHI(2,2);
    vecteur PHI(2);
    vecteur e1(2);
    vecteur e2(2);
    double i=0;
    double i_max=15;


    PHI(0)=1;//Permet de commencer le while
    Y=X; // on continue avec Y pour ne pas modifier X

    // Choix du point pour commencer le gradient conjugué
    e1(0)=0.1;
    e1(1)=0.1;
    while(PHI.norm_infini()>precision && i<i_max) 
    {
        DPHI=dphi2(Y,delta_t,lambda); // on stocke D_phi
        PHI=phi2(Y,X,delta_t,lambda); // on stocke phi
        e2=(-1)*PHI; // on multiplie par -1 phi pour pouvoir résoudre GC
        e1=DPHI.gc(e2,e1,1e-10,100); // on applique GC
        Z=Y+e1; // méthode de newton
        Y=Z; // on affecte Z à Y, ce qui augmentera la précision finale
        i=i+1;
    }
    return Y;
}

vecteur solvenew2( vecteur& U0,  double& T,  double& delta_t, double& lambda, double& precision, const char* theta, const char* theta_prime, const char* hamilton)
{
    // Initialisation
    vecteur Y(2);
    double t=0;
    double ite=int(T/delta_t)+1;

    // Ouverture fichier
    ofstream file(theta);
    ofstream file1(theta_prime);
    ofstream file2(hamilton);

    for (int n = 0; n < ite; n++) // le nombre d'itération pour réaliser newton
    {
        Y=U0; // on garde U0
        Y=newton2(Y,delta_t,lambda,precision); // On applique une itération de newton
        file << t << " "<< Y(0)<<endl;
        file1 << t << " " << Y(1) << endl;
        file2 << t << " " << (pow(Y(1),2)/2)-cos(Y(0)) << endl;
        U0=Y; // "U0 devient Y, i.e. U1"
        t=t+delta_t;
    }
    // Fermeture ficheir
    file.close();
    file1.close();
    file2.close();
    return Y;
}


double pendule_amorti(double& T, double& delta_t, double& v0,double& lambda,const char* LeFichier,const char* LePrime)
{
    // Initialisation
    double ite=int(T/delta_t)+1;
    double t=0;
    double v=0;
    double w=0;
    double omega= 1-(pow(lambda,2)/4);

    // Ouverture fichier
    ofstream file(LeFichier);
    ofstream file2(LePrime);
    for (int i=0; i<ite; i++)
    {
        // Solution exacte
        v=(v0/omega)*(sin(omega*t))*(exp(-(lambda/2)*t)); //theta
        w=(exp(-(lambda/2)*t)*v0)*(-(sin(omega*t)/omega)*(lambda/2)+cos(omega*t)); //theta prime
        file <<t << " " << v << endl;
        file2 << t << " " << w << endl;
        t=t+delta_t;
    }
    file.close();
    cout << "T = " << T << " delta_t = " << delta_t << " nb d'iter = " << ite << endl ;
    return v;
}