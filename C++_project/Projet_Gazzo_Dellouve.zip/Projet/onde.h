// ==================================================
// ==           Par                                ==
// ==      Sandro Gazzo                            ==
// ==           Et                                 ==
// ==      Théo Dellouve                           ==
// ==================================================



#include <iostream>
#include <assert.h>
#include <math.h>
#include <string>
#include <fstream>
#include "matrice.h"
#define pi 3.141592653558979323846
using namespace std;

class onde
{
    public:
        vecteur u0(int&, double&, int&); // donne u0 selon le choix : u0(N, a, choix)
        vecteur ut(int&, double&, int&); // donne ut selon le choix : ut(N, a, b, choix)
        vecteur solexacte(double&,int&); // la solution exacte
        vecteur ondes_euler_explicite(double&, double&, int&, int&, const char*, const char*, const char*); // schéma euler explicite
        vecteur ondes_euler_implicite(double&, double&, int&, int&, const char*, const char*, const char*); // schéma euler implicite
        vecteur ondes_crank_nicolson(double&, double&, int&, int&, const char*, const char*, const char*); // schéma Crank-Nicolson
};


vecteur onde :: u0(int& N,double& a, int& choix)
{
    // choix 1 : pincement d'une corde de guitare
    // choix 2 : frottement d'une corde de violon
    // choix 3 : corde d'un piano frappée
    // choix 4 : solution approchée d'une solution exacte
    // choix de a nécessaire pour choix 1 et choix 4
    assert(a<1 && a>0);
    vecteur x(N+1);
    for (int j=0; j<N+1; j++) // mauvais N ??
    {
        x(j)= double(j)/(N);
    }
    vecteur u0(N+1);

    //-------------------------
    if (choix==1)
    {
    for (int j=0; j<N+1;j++)
    {
        if (x(j)<=a)
        {
            u0(j)=x(j)/a;
        }
        else
        {
            u0(j)=(1-x(j))/(1-a);
        }
    }
    }
    //-------------------------
    if (choix==2)
    {
        for (int j=0; j<N+1;j++)
        {
            u0(j)=4*x(j)*(1-x(j));
        }
    }
    //-------------------------
    if (choix==3)
    {
        for (int j=0; j<N+1;j++)
        {
        u0(j)=0;
        }
    }
    //-------------------------
    if (choix==4)
    {
        for (int j = 0; j < N+1; j++)
        {
            u0(j)=sin(pi*x(j));
        }
        
    }
return u0;
}

vecteur onde :: ut(int& N,double& a, int& choix)
{
    // choix 1 : pincement d'une corde de guitare
    // choix 2 : frottement d'une corde de violon
    // choix 3 : corde d'un piano frappée
    // choix 4 : solution approchée d'une solution exacte
    // choix de a nécessaire pour choix 1 et choix 4
    assert(a<0.9 && a>0);
    vecteur x(N+1);
    double b=0.1;
    double c0=20.0;
    for (int j=0; j<N+1; j++) // mauvais N ??
    {
        x(j)= double(j)/(N+1);
    }
    vecteur ut(N+1);
    //-------------------------
    if (choix==1)
    {
        for (int j=0; j<N+1;j++)
        {
        ut(j)=0;
        }
    }
    //-------------------------
    if (choix==2)
    {
       for (int j=0; j<N+1;j++)
        {
        ut(j)=0;
        }
    }
    //-------------------------
    if (choix==3)
    {
        for(int j=0; j<N+1; j++)
        {
        if ((x(j)>a)&&(x(j)<=a+b))
        {            
            ut(j)=c0;
            
        }
        else
        {
        ut(j)=0;
        }
        }
    }
    if (choix==4)
    {
        for (int j=0; j<N+1;j++)
        {
            // ut(j)=(pi*(j+1))*cos(pi*(j+1)*x(j));
            ut(j)=0;
        }

    }
    //-------------------------
    
return ut;
}


// Calcule de la solution excate
vecteur solexacte(double& T,int& N)
{
    //  Initialisation
    vecteur solu(N+1);
    vecteur x(N+1);
    for (int j=0; j<N+1; j++) 
    {
        x(j)= double(j)/(N);
    }
    for (int j=1; j<N; j++)
    {
        solu(j)=(sin(pi*(x(j)-T))+sin(pi*(x(j)+T)))/2;
    }
    return solu;   
}

vecteur ondes_euler_explicite(double& T,double& CFL, int& N, int& choix, const char* LeFichier, const char* norme2, const char* normeInf)
{
    onde O; // classe onde

    //Vecteurs de stockage
    vecteur u0(N+1);
    vecteur ut(N+1);
    vecteur u1(N+1);
    vecteur u(N+1);
    vecteur mu(N+1);
    vecteur lam(N+1);

    //Données
    double delta_x=1.0/N;
    double delta_t=CFL*delta_x;
    double a=pow(delta_t,2)/pow(delta_x,2);
    int tps=floor(T/delta_t);
    double c=0.5;

    //Solutions initiales
    u0=O.u0(N,c,choix);
    ut=O.ut(N,c,choix); // necessaire au calcul de u1
    u1=delta_t*ut+u0; // on calcule u1 avec a formule ut(x,0)=(u(x,dt)-u(x,0))/dt

    // Ouverture fichier
    ofstream file(LeFichier);
    ofstream file1(norme2);
    ofstream file2(normeInf);

    // Stockage données
    lam=u0;
    mu=u1;
    double new_delta_t =delta_t;
    
    for (int i=1; i<=tps; i++) // k...
    {

        for (int j=1; j<N; j++)
        {
            u(j)=2*mu(j)+(mu(j+1)-2*mu(j)+mu(j-1))*a-lam(j);
            file <<j*delta_x << " " << u(j) << endl; // ecriture du vecteur dans le ficheir
        }
        new_delta_t=new_delta_t+delta_t;
        file1 << new_delta_t << " " << u.norm_2()<< endl; // norme L2 dans le fichier
        file2 << new_delta_t << " " << u.norm_infini()<< endl; // norme L inf dans le fichier

        lam=mu; // "u0 devient u1"
        mu=u; // "u1 devient u2"
        file << endl << endl;
    }    
    // Fermeture des fichiers
    file.close();
    file1.close();
    file2.close();
    cout << "N = " << N << " delta_t = " << delta_t << " iter en temps = " << tps << endl ;
    return u;
}



vecteur ondes_euler_implicite(double& T,double& CFL, int& N, int& choix, const char* LeFichier, const char* norme2, const char* normeInf)
{
    onde O; // classe onde

    //Vecteurs de stockage
    vecteur u0(N+1);
    vecteur ut(N+1);
    vecteur u1(N+1);
    vecteur u(N+1);
    vecteur mu(N+1);
    vecteur lam(N+1);
    vecteur b(N+1);

    //Données
    double delta_x=1.0/N;
    double delta_t=CFL*delta_x;
    double a=pow(delta_t,2)/pow(delta_x,2);
    int tps=floor(T/delta_t);
    double c=0.5;

    //Solutions initiales
    u0=O.u0(N,c,choix);
    ut=O.ut(N,c,choix); // necessaire au calcul de u1
    u1=delta_t*ut+u0; // on calcul u1 avec a formule ut(x,0)=(u(x,dt)-u(x,0))/dt

    //Matrice tridiagonale
    matrice A(N+1,N+1);
    A(0,1)=-a;
    A(N,N-1)=-a;
    A(0,0)=1.0+2*a;
    A(N,N)=1.0+2*a;
    for(int j=1;j<N;j++)
    {
        A(j,j)=1+2*a ;
        A(j,j-1)=-a ;
        A(j,j+1)=-a ;
    }

    // Factorisation LU de M
    vecteur pivot(N+1);
    matrice L(N+1,N+1);
    L=A.lu(pivot);

    // Ouverture des fichiers
    ofstream file(LeFichier);
    ofstream file1(norme2);
    ofstream file2(normeInf);

    // Stockage données
    lam=u0;
    mu=u1;
    double new_delta_t =delta_t;

    for(int i=1;i<=tps;i++)
    {
        b=2*mu-lam;
        u=L.solvelu(b,pivot); 
        for(int j=1;j<N;j++)
        {
            file<<j*delta_x << " " << u(j) << endl; // ecriture du vecteur dans le fichier
        }
        new_delta_t=new_delta_t+delta_t;
        file1 << new_delta_t << " " << u.norm_2()<< endl; //ecriture norme L2
        file2 << new_delta_t << " " << u.norm_infini()<< endl; //ecriture norme L_inf

        lam=mu; // "u0 devient u1"
        mu=u; // "u1 devient u2"
        
        file << endl << endl;
    }
    // Fermeture fichier
    file.close();
    file1.close();
    file2.close();



    cout << "N = " << N << " delta_t = " << delta_t << " iter en temps = " << tps << endl ;
    return u;
}

vecteur ondes_crank_nicolson(double& T,double& CFL, int& N, int& choix, const char* LeFichier, const char* norme2, const char* normeInf,const char* Energie)
{
    onde O; // classe onde

    //Vecteurs de stockage
    vecteur u0(N+1);
    vecteur ut(N+1);
    vecteur u1(N+1);
    vecteur u(N+1);
    vecteur mu(N+1);
    vecteur lam(N+1);
    vecteur b(N+1);
    double E;
    double S1=0;
    double S2=0;
    double S3=0;

    //Données
    double delta_x=1.0/N;
    double delta_t=CFL*delta_x;
    double a=pow(delta_t,2)/(2*pow(delta_x,2));
    int tps=floor(T/delta_t);
    double c=0.5;

    //Solutions initiales
    u0=O.u0(N,c,choix);
    ut=O.ut(N,c,choix); // necessaire au calcul de u1
    u1=delta_t*ut+u0; // on calcul u1 avec a formule ut(x,0)=(u(x,dt)-u(x,0))/dt

    //Matrice tridiagonale
    matrice A(N+1,N+1);
    A(0,1)=-a;
    A(N,N-1)=-a;
    A(0,0)=1.0+2*a;
    A(N,N)=1.0+2*a;

    for(int j=1;j<N;j++)
    {
        A(j,j)=1+2*a;
        A(j,j-1)=-a;
        A(j,j+1)=-a;
    }

    // Factorisation LU de M
    vecteur pivot(N+1);
    matrice L(N+1,N+1);
    L=A.lu(pivot);

    // Boucle en temps et generation du fichier de donnees
    ofstream file(LeFichier);
    ofstream file1(norme2);
    ofstream file2(normeInf);
    ofstream file3(Energie);
    
    double new_delta_t =delta_t;
    lam=u0;
    mu=u1;
    for(int i=1;i<=tps;i++)
    {
        b=2*mu-A*lam;
        u=L.solvelu(b,pivot);

        for(int j=1;j<N;j++)
        {
            file<<j*delta_x << " " <<u(j) << endl;
        }
        // Calcul de l'energie
        for(int k=0;k<N+1;k++)
        {
            S1=S1+(1.0/pow(delta_t,2))*pow((mu(k)-lam(k)),2); 
        }
        for (int k = 0; k < N; k++)
        {
            S2=S2+(1.0/pow(delta_x,2))*pow(mu(k+1)-mu(k),2);
            S3=S3+(1.0/pow(delta_x,2))*pow(lam(k+1)-lam(k),2);
        }
        E=(delta_x/2)*(S1+((1.0/2)*(S2+S3)));
        file3<<new_delta_t << " " << E << endl;
        // on remet à zero les sommes
        S1=0;
        S2=0;
        S3=0;
        new_delta_t=new_delta_t+delta_t;
        file1 << new_delta_t << " " << u.norm_2()<< endl;
        file2 << new_delta_t << " " << u.norm_infini()<< endl;
        lam=mu; //"u0 devient u1"
        mu=u; // "u1 devient u2"
        
        file << endl << endl;
        }
    // Fermeture fichier
    file.close();
    file1.close();
    file2.close();
    file3.close();
    
    cout << "N = " << N << " delta_t = " << delta_t << " iter en temps = " << tps << endl ;
    return u;
}




