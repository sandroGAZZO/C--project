# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 14:51:40 2020

@author: Akuryou
"""


from scipy.io.wavfile import read
import numpy as np
import matplotlib.pyplot as plt
from scipy.fftpack import fft, fftfreq

sampling_rate,signal = read("Mrs_mc_damott.wav") #on ouvre le fichier audio

signal=signal-np.mean(signal) #On supprime la composante continue du signal

#print(signal)

t0=0 #temps initial, donc 0
t1=18 #temps d'arrêt du fichier audio: ici 18 secondes
N=np.size(signal)//2 #nombre de points échantillonnés sur l'intervalle
FreqEch = N/t1 #fréquence des échantillons sur l'intervalle
PerEch = 1./FreqEch #la période des échantillonages


t = np.linspace(t0, t1, N) #On modélise le temps
signal1=signal[:,0] #On récupère le "signal 1"
signal2=signal[:,1] #On récupère le "signal 2"

# définition des données de FFT
FenAcq = signal2.size # taille de la fenetre temporelle
print(FenAcq)
# calcul de la TFD par l'algo de FFT
signal_FFT = abs(fft(signal2)) # on ne récupère que les composantes réelles
print(signal_FFT)

signal_freq = fftfreq(FenAcq,PerEch) #on récupère le domaine fréquentiel
print(signal_freq)


signal_FFT = signal_FFT[0:len(signal_FFT)//2] #on extrait les valeurs réelles de la FFT
signal_freq = signal_freq[0:len(signal_freq)//2] #on extrait les valeurs réelles du domaine fréquentiel

#on affiche le signal
plt.subplot(211)
plt.title('Signal et son spectre')
plt.plot(t, signal2)
plt.xlabel('Temps (s)'); plt.ylabel('Amplitude')



#affichage du spectre du signal
plt.subplot(212)
plt.xlim(200,2000)
plt.plot(signal_freq,signal_FFT)
plt.xlabel('Frequence (Hz)'); plt.ylabel('Amplitude')
plt.show()

#%% 
# fft puissance de 2:

def fft_2(x):
        M=x.size//2
        if M==1:
            return np.array([x[0]+x[1],x[0]-x[1]],dtype=np.complex64)/2
        else:
            x1=fft(x[::2])
            x2=np.exp(1j*np.pi/M*np.arange(0,M))*fft(x[1::2])
            return np.concatenate((x1+x2,x1-x2))/2
        
#%%
#Noyau rectangualire fft  
            
    
N=1000
F=np.pi**(-1./4)*np.exp(-1/2*(18/60)**2)#temps d'arrêt du fichier audio: ici 18 secondes
B=len(signal[:,1])/F
taille=820*2-1
V=np.zeros((taille,2))


for i in range (0,taille):
    t0=i/2*F
    t1=(i/2+1)*F
 #nombre de points échantillonnés sur l'intervalle
    FreqEch = 32.78*N/(t1-t0) #fréquence des échantillons sur l'intervalle
    PerEch = 1./FreqEch #la période des échantillonages
    
    t = np.linspace(t0, t1, N) #On modélise le temps

    signal1=signal[int(i/2)*N:int(i/2+1)*N,0]#*np.exp(-(1./2)*(t-b)**2)*np.exp(2*np.pi*1j*t[j]) #On récupère le "signal 1"
    
    
 
# définition des données de FFT
    FenAcq = signal1.size # taille de la fenetre temporelle

# calcul de la TFD par l'algo de FFT
    signal_FFT = abs(fft(signal1)) # on ne récupère que les composantes réelles


    signal_freq = fftfreq(FenAcq,PerEch) #on récupère le domaine fréquentiel



    signal_FFT = signal_FFT[0:len(signal_FFT)//2] #on extrait les valeurs réelles de la FFT
    signal_freq = signal_freq[0:len(signal_freq)//2] #on extrait les valeurs réelles du domaine fréquentiel

    V[i,:]=[signal_freq[np.argmax(signal_FFT)],signal_FFT[np.argmax(signal_FFT)]]
    
print(V)

k=np.linspace(0,18,taille)
plt.xlabel("Temps (s)");plt.ylabel("Fréquence (Hz)")
plt.title("Original")
plt.plot(k,V[:,0],".")
plt.show()

k=np.linspace(0,18,taille)
plt.ylim(0,1000)
plt.xlabel("Temps (s)");plt.ylabel("Fréquence (Hz)")
plt.title("En enlevant les gros silences")
plt.plot(k,V[:,0],".")
plt.show()

k=np.linspace(0,18,taille)
plt.ylim(190,610)
plt.xlabel("Temps (s)");plt.ylabel("Fréquence (Hz)")
plt.title("En épurant un maximum: Partition finale")
plt.plot(k,V[:,0],".")
plt.show()


#%%
#Noyau rectangualire fft puissance de 2

N=1024
F=18*N/(820416.0) #temps d'arrêt du fichier audio: ici 18 secondes
B=len(signal[:,1])/F
taille=1604
V=np.zeros((taille,2))


for i in range (0,taille):
    t0=i/2*F
    t1=(i/2+1)*F
 #nombre de points échantillonnés sur l'intervalle
    FreqEch = N/(t1-t0) #fréquence des échantillons sur l'intervalle
    PerEch = 1./FreqEch #la période des échantillonages


    t = np.linspace(t0, t1, N) #On modélise le temps
    signal1=signal[int(i/2)*N:int(i/2+1)*N,0] #On récupère le "signal 1"

# définition des données de FFT
    FenAcq = signal1.size # taille de la fenetre temporelle

# calcul de la TFD par l'algo de FFT
    signal_FFT = abs(fft_2(signal1)) # on ne récupère que les composantes réelles


    signal_freq = fftfreq(FenAcq,PerEch) #on récupère le domaine fréquentiel



    signal_FFT = signal_FFT[0:len(signal_FFT)//2] #on extrait les valeurs réelles de la FFT
    signal_freq = signal_freq[0:len(signal_freq)//2] #on extrait les valeurs réelles du domaine fréquentiel

    V[i,:]=[signal_freq[np.argmax(signal_FFT)],signal_FFT[np.argmax(signal_FFT)]]
    
print(V)

k=np.linspace(0,18,taille)
plt.xlabel("Temps (s)");plt.ylabel("Fréquence (Hz)")
plt.title("Original")
plt.plot(k,V[:,0],".")
plt.show()

k=np.linspace(0,18,taille)
plt.ylim(0,1000)
plt.xlabel("Temps (s)");plt.ylabel("Fréquence (Hz)")
plt.title("En enlevant les gros silences")
plt.plot(k,V[:,0],".")
plt.show()

k=np.linspace(0,18,taille)
plt.ylim(190,610)
plt.xlabel("Temps (s)");plt.ylabel("Fréquence (Hz)")
plt.title("En épurant un maximum: Partition finale")
plt.plot(k,V[:,0],".")
plt.show()

##%%
##Noyau gaussien
#
#b=0
#i=0
#taille=900*2
#V=np.zeros((taille,2))
#signal2=signal[:,1]
#while b<18:
#    
#    t = np.linspace(0,18, np.size(signal2))
#    #t = np.linspace(b-0.15,b+0.15, 1024)
#    y=np.pi**(-1./4)*np.exp(-1./0.00005*(t-b)**2)
#    #plt.plot(t,y)
#    #plt.xlim(b-0.02,b+0.02)
#    #plt.show()
#    
#    y=signal2*y
#    #y=signal2[1024*int(b/0.01):1024*int(b/0.01+1)]*y
#    #plt.plot(t,y, color='orange')
#    #plt.xlim(b-0.02,b+0.02)
#    #plt.show()
#    b=b+0.01
#    
#    N=np.size(signal2)
#    F=18 #temps d'arrêt du fichier audio: ici 18 secondes
#    B=len(signal[:,1])/F
#    
#    FenAcq = y.size # taille de la fenetre temporelle    
#    signal_FFT = abs(fft(y)) # on ne récupère que les composantes réelles  
#    signal_freq = fftfreq(FenAcq,PerEch) #on récupère le domaine fréquentiel
#    signal_FFT = signal_FFT[0:len(signal_FFT)//2] #on extrait les valeurs réelles de la FFT
#    signal_freq = signal_freq[0:len(signal_freq)//2] #on extrait les valeurs réelles du domaine fréquentiel
#
#    
#    V[i,:]=[signal_freq[np.argmax(signal_FFT)],signal_FFT[np.argmax(signal_FFT)]]
#    i=i+1
#   # plt.xlim(signal_freq[np.argmax(signal_FFT)]-150,signal_freq[np.argmax(signal_FFT)]+150)
#   # plt.plot(signal_freq,signal_FFT)
#   # plt.xlabel('Frequence (Hz)'); plt.ylabel('Amplitude')
#   # plt.show()
#
#    
#print(V)
#
#k=np.linspace(0,18,taille)
#plt.xlabel("Temps (s)");plt.ylabel("Fréquence (Hz)")
##plt.ylim(190,610)
#plt.title("Original")
#plt.plot(k,V[:,0],".")
#plt.show()



