import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from mpl_toolkits.mplot3d import Axes3D

#%% theta(t) et theta'(t)

#### v0=0.5

f = open("theta1.txt", "r")
c=np.loadtxt(f)

plt.plot(c[:,0],c[:,1])
plt.title("thêta en fonction de t pour le pendule simple, v0=0.5")
plt.xlabel("t")
plt.ylabel("thêta")
plt.show()

f = open("theta'1.txt", "r")
c=np.loadtxt(f)

plt.plot(c[:,0],c[:,1])
plt.title("thêta' en fonction de t pour le pendule simple, v0=0.5")
plt.xlabel("t")
plt.ylabel("thêta'")
plt.show()

#### v0=3

f = open("theta2.txt", "r")
c=np.loadtxt(f)

plt.plot(c[:,0],c[:,1])
plt.title("thêta en fonction de t pour le pendule simple, v0=3")
plt.xlabel("t")
plt.ylabel("thêta")
plt.show()

f = open("theta'2.txt", "r")
c=np.loadtxt(f)

plt.plot(c[:,0],c[:,1])
plt.title("thêta' en fonction de t pour le pendule simple, v0=3")
plt.xlabel("t")
plt.ylabel("thêta'")
plt.show()

#%% HAMILTONIEN
f = open("hamiltonien1.txt", "r")
c=np.loadtxt(f)

plt.plot(c[:,0],c[:,1])
plt.xlabel("t")
plt.ylabel("E(thêta,thêta')")
plt.title("Hamiltonien en fonction du temps pour le pendule simple, v0=0.5")
plt.show()

f = open("hamiltonien2.txt", "r")
c=np.loadtxt(f)


plt.plot(c[:,0],c[:,1])
plt.xlabel("t")
plt.ylabel("E(thêta,thêta')")
plt.ylim(3,4)
plt.title("Hamiltonien en fonction du temps pour le pendule simple, v0=3")
plt.show()

#%%  Lignes de niveau

def g(x,y):
    return (y**2/2-np.cos(x))
N=1000
x=np.linspace(-4,4,N)
y=np.linspace(-3,3,N)
xx,yy=np.meshgrid(x,y)
zz=g(xx,yy)
C=np.array([-0.7,-0.5,0.0,0.5,1.0,1.5,2]) # les 'a' de 'E(x,y)=a'
lignes_niveaux=plt.contour(xx,yy,zz,levels=C)
plt.clabel(lignes_niveaux,C)
plt.title("Lignes de niveau de l'Hamiltonien du pendule simple non amorti")
plt.show()

#%% pendule amorti approx numérique

#### v0=0.5

f = open("theta3.txt", "r")
c1=np.loadtxt(f)

plt.plot(c1[:,0],c1[:,1])
plt.title("thêta en fonction de t pour le pendule amorti, v0=0.5")
plt.xlabel("t")
plt.ylabel("thêta")
plt.show()

f = open("theta'3.txt", "r")
c2=np.loadtxt(f)

plt.plot(c2[:,0],c2[:,1])
plt.title("thêta' en fonction de t pour le pendule amorti, v0=0.5")
plt.xlabel("t")
plt.ylabel("thêta'")
plt.show()

#ORBITE

plt.plot(c1[:,1],c2[:,1])
plt.title("Orbite pour v0=0.5")
plt.xlabel("theta")
plt.ylabel("theta'")
plt.show()


#### v0=3

f = open("theta4.txt", "r")
c1=np.loadtxt(f)

plt.plot(c1[:,0],c1[:,1])
plt.title("thêta en fonction de t pour le pendule amorti, v0=3")
plt.xlabel("t")
plt.ylabel("thêta")
plt.show()

f = open("theta'4.txt", "r")
c2=np.loadtxt(f)

plt.plot(c2[:,0],c2[:,1])
plt.title("thêta' en fonction de t pour le pendule amorti, v0=3")
plt.xlabel("t")
plt.ylabel("thêta'")
plt.show()

#ORBITE

plt.plot(c1[:,1],c2[:,1])
plt.title("Orbite pour v0=3")
plt.xlabel("theta")
plt.ylabel("theta'")
plt.show()

#%%

#### hamiltoniens

f = open("hamiltonien3.txt", "r")
c=np.loadtxt(f)

plt.plot(c[:,0],c[:,1])
plt.xlabel("t")
plt.ylabel("E(thêta,thêta')")
plt.title("Hamiltonien en fonction du temps pour le pendule amorti, v0=0.5")
plt.show()

f = open("hamiltonien4.txt", "r")

c=np.loadtxt(f)


plt.plot(c[:,0],c[:,1])
plt.xlabel("t")
plt.ylabel("E(thêta,thêta')")
plt.title("Hamiltonien en fonction du temps pour le pendule amorti, v0=3")
plt.show()




#%%
# version linéaire

#### v0=0.5

f = open("solution1.txt", "r")
c1=np.loadtxt(f)
plt.plot(c1[:,0],c1[:,1])
plt.xlabel("t")
plt.ylabel("thêta")
plt.title("theta en fonction de t pour le pendule version linéaire, v0=0.5")
plt.show()


f = open("solution_prime1.txt", "r")
c2=np.loadtxt(f)
plt.plot(c2[:,0],c2[:,1])
plt.xlabel("t")
plt.ylabel("thêta")
plt.title("theta' en fonction de t pour le pendule version linéaire, v0=0.5")
plt.show()

plt.plot(c1[:,1],c2[:,1])
plt.title("Orbite pour v0=0.5")
plt.xlabel("theta")
plt.ylabel("theta'")
plt.show()

#%%

#### v0=3

f = open("solution2 (2).txt", "r")
c1=np.loadtxt(f)
plt.plot(c1[:,0],c1[:,1])
plt.xlabel("t")
plt.ylabel("thêta")
plt.title("theta en fonction de t pour le pendule version linéaire, v0=3")
plt.show()


f = open("solution_prime2.txt", "r")
c2=np.loadtxt(f)
plt.plot(c2[:,0],c2[:,1])
plt.xlabel("t")
plt.ylabel("thêta")
plt.title("theta' en fonction de t pour le pendule version linéaire, v0=3")
plt.show()

plt.plot(c1[:,1],c2[:,1])
plt.title("Orbite pour v0=3")
plt.xlabel("theta")
plt.ylabel("theta'")
plt.show()

#%% q5


#### v0=0.5

f = open("theta5.txt", "r")
c1=np.loadtxt(f)

plt.plot(c1[:,0],c1[:,1])
plt.title("thêta en fonction de t pour le pendule amorti entretenu, v0=0.5")
plt.xlabel("t")
plt.ylabel("thêta")
plt.show()

f = open("theta'5.txt", "r")
c2=np.loadtxt(f)

plt.plot(c2[:,0],c2[:,1])
plt.title("thêta' en fonction de t pour le pendule amorti entretenu, v0=0.5")
plt.xlabel("t")
plt.ylabel("thêta'")
plt.show()

#ORBITE

plt.plot(c1[:,1],c2[:,1])
plt.title("Orbite pour v0=0.5")
plt.xlabel("theta")
plt.ylabel("theta'")
plt.show()


#%%

#### v0=3

f = open("theta6.txt", "r")
c1=np.loadtxt(f)

plt.plot(c1[:,0],c1[:,1])
plt.title("thêta en fonction de t pour le pendule amorti entretenu, v0=3")
plt.xlabel("t")
plt.ylabel("thêta")
plt.show()

f = open("theta'6.txt", "r")
c2=np.loadtxt(f)

plt.plot(c2[:,0],c2[:,1])
plt.title("thêta' en fonction de t pour le pendule amorti entretenu, v0=3")
plt.xlabel("t")
plt.ylabel("thêta'")
plt.show()

#ORBITE

plt.plot(c1[:,1],c2[:,1])
plt.title("Orbite pour v0=3")
plt.xlabel("theta")
plt.ylabel("theta'")
plt.show()


#%%
# HAMILTONIEN

f = open("hamiltonien5.txt", "r")
c=np.loadtxt(f)

plt.plot(c[:,0],c[:,1])
plt.xlabel("t")
plt.ylabel("E(thêta,thêta')")
plt.title("Hamiltonien en fonction du temps pour le pendule amorti entretenu, v0=0.5")
plt.show()

f = open("hamiltonien6.txt", "r")

c=np.loadtxt(f)


plt.plot(c[:,0],c[:,1])
plt.xlabel("t")
plt.ylabel("E(thêta,thêta')")
plt.title("Hamiltonien en fonction du temps pour le pendule amorti entretenu, v0=3")
plt.show()

