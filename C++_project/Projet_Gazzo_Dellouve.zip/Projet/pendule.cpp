// ==================================================
// ==           Par                                ==
// ==      Sandro Gazzo                            ==
// ==           Et                                 ==
// ==      Théo Dellouve                           ==
// ==================================================


#include <iostream>
#include "pendule.h"
#include <fstream>
#include <cmath>
#include <sstream>
#include <string>
#include <assert.h>
#include <time.h>
using namespace std;

int main(){
    // Initialisation
    double T=50;
    double delta_t=0.01;
    double v0=0.5;
    double lambda=0.1;
    double gamma=0;
    double precision=pow(10,-10);
    vecteur solution(2);
    vecteur solution_ref(2);
    vecteur hamiltonien(2);
    int choix=1;
    double zero;
    int choice=2;
    solution_ref(0)=0;
    

    solution_ref(1)=v0;

    // -----------------------------------------------------------------------
    // Stockage des solutions
    solution=solution_ref;
    cout << "Premier modèle"<<endl;
    cout << "lambda="<< gamma<<endl;
    cout << "v0="<<v0<<endl<<endl;
    hamiltonien=solvenew1(solution,T,delta_t,gamma,precision,"theta1.txt","theta'1.txt","hamiltonien1.txt");
    
    solution=solution_ref;
    cout << "Premier modèle"<<endl;
    cout << "lambda="<< lambda<<endl;
    cout << "v0="<<v0<<endl<<endl;
    hamiltonien=solvenew1(solution,T,delta_t,lambda,precision,"theta3.txt","theta'3.txt","hamiltonien3.txt");
    
    cout << "Solution exacte"<<endl;
    cout << "lambda="<< lambda<<endl;
    cout << "v0="<<v0<<endl<<endl<<endl;
    zero=pendule_amorti(T,delta_t,v0,lambda,"solution1.txt","solution_prime1.txt");

    solution=solution_ref;
    cout << "Second modèle modèle"<<endl;
    cout << "lambda="<< lambda<<endl;
    cout << "v0="<<v0<<endl;
    hamiltonien=solvenew2(solution,T,delta_t,lambda,precision,"theta5.txt","theta'5.txt","hamiltonien5.txt");
    
    
    v0=3;
    solution_ref(1)=v0;
    
    solution=solution_ref;
    cout << "Premier modèle"<<endl;
    cout << "lambda="<< gamma<<endl;
    cout << "v0="<<v0<<endl<<endl;
    hamiltonien=solvenew1(solution,T,delta_t,gamma,precision,"theta2.txt","theta'2.txt","hamiltonien2.txt");
    
    solution=solution_ref;
    cout << "Premier modèle"<<endl;
    cout << "lambda="<< lambda<<endl;
    cout << "v0="<<v0<<endl<<endl;
    hamiltonien=solvenew1(solution,T,delta_t,lambda,precision,"theta4.txt","theta'4.txt","hamiltonien4.txt");
    
    cout << "Solution exacte"<<endl;
    cout << "lambda="<< lambda<<endl;
    cout << "v0="<<v0<<endl<<endl;
    zero=pendule_amorti(T,delta_t,v0,lambda,"solution2.txt","solution_prime2.txt");

    solution=solution_ref;
    cout << "Second modèle"<<endl;
    cout << "lambda="<< lambda<<endl;
    cout << "v0="<<v0<<endl<<endl;
    hamiltonien=solvenew2(solution,T,delta_t,lambda,precision,"theta6.txt","theta'6.txt","hamiltonien6.txt");
    
    return 0;
}