// ==================================================
// ==           Par                                ==
// ==      Sandro Gazzo                            ==
// ==           Et                                 ==
// ==      Théo Dellouve                           ==
// ==================================================


#include <iostream>
#include "fisher.h"
#include <fstream>
#include <cmath>
#include <sstream>
#include <string>
#include <assert.h>
#include <time.h>


using namespace std;

int main(){
    // Initialisation
    double Nx=20;
    double Ny=20;
    double D=0.1;
    double delta_t=0.01;
    double alpha;
    double omega=0.1;
    double T=1.0;
    double beta;
    vecteur P1(Nx-1);
    vecteur N1(Nx-1);
    vecteur deb(Nx-1);
    matrice PF(Nx-1,Ny-1);
    matrice NE(Nx-1,Ny-1);
    matrice BEG(Nx-1,Ny-1);

    // -------------------------------------------------------------------


    vecteur ALPHA(6);
    ALPHA(0)=10.0;
    ALPHA(1)=0.0;
    ALPHA(2)=20.0;
    ALPHA(3)=50.0;
    ALPHA(4)=100.0;
    ALPHA(5)=200.0;



    // Dans un premier temps, nous allons tracer les graphiques
    // avec gnuplot. Nous stockerons ensuite les fichiers. Nous
    //  trouvons cela plus agréable à regarder et à écrire même
    // si nous faisons deux fois les calculs.

    // D'abord en dimension 1
    cout<< "Dimension=1"<<endl;

    for (int i = 0; i < 6; i++)
    {
    alpha=ALPHA(i); 
    cout << "alpha="<<alpha << endl;

    deb=init_1d(Nx);
    cout << "Point fixe"<<endl;
    P1=solvepfixe_1d(deb,T,omega,delta_t, D,alpha, "point fixe 1D.txt");
    deb=init_1d(Nx);
    cout << "Newton"<<endl<<endl;
    N1=solvenew_1d(deb,T,delta_t,D,alpha,"newton 1D.txt");

    double xmin=0;
    double xmax=1;
    double ymin=0;
    double ymax=1;

    ofstream file2("film1.gnuplot");
    //file2 << "set terminal x11" << endl;
    file2 << "set xrange[" << xmin << ":" << xmax << "]" << endl; //fenetre sur l'abscisse
    file2 << "set yrange[" << ymin << ":" << ymax << "]" << endl; //fenetre sur l'ordonné
    file2 << "imax=" << 5*Nx << endl; 
    file2 << "i=0" << endl;
    file2 << "load \"script1.gnu\" ";
    file2.close();

    ofstream file3("script1.gnu");
    file3 << "plot \"point fixe 1D.txt\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file3 << "pause" << " " << 0.05 <<  endl;
    file3 << "i=i+1"<< endl;
    file3 << "if (i<imax) reread" << endl;
    file3 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot");

    ofstream file4("film1.gnuplot");
    //file4 << "set terminal x11" << endl;
    file4 << "set xrange[" << xmin << ":" << xmax << "]" << endl; //fenetre sur l'abscisse
    file4 << "set yrange[" << ymin << ":" << ymax << "]" << endl; //fenetre sur l'ordonné
    file4 << "imax=" << 5*Nx << endl; 
    file4 << "i=0" << endl;
    file4 << "load \"script1.gnu\" ";
    file4.close();


    ofstream file5("script1.gnu");
    file5 << "plot \"newton 1D.txt\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file5 << "pause" << " " << 0.05 <<  endl;
    file5 << "i=i+1"<< endl;
    file5 << "if (i<imax) reread" << endl;
    file5 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot");
    }


    // ----------------------------------------------------------------
    vecteur BETA(5);
    BETA(0)=1.0;
    BETA(1)=0.0;
    BETA(2)=2.0;
    BETA(3)=10.0;
    BETA(4)=20.0;

    // Graphique pour 2d

    cout << "Dimension=2"<<endl;

    for (int i = 0; i < 5; i++)
    {
    beta=BETA(i);
    cout<< "alpha="<<beta<<endl;
    
    BEG=init_2d(Nx,Ny);
    cout << "Point fixe"<<endl;
    PF=solvepfixe_2d(BEG,T,omega,delta_t,D,beta,"point fixe 2D.txt");
    BEG=init_2d(Nx,Ny);
    cout << "Newton"<<endl;
    NE=solvenew_2d(BEG,T,delta_t,D,beta, "newton 2D.txt");


    double xmin=0;
    double xmax=1;
    double ymin=0;
    double ymax=1;
    double zmin=0;
    double zmax=1;
    ofstream file6("film2.gnuplot");
    //file6 << "set terminal x11" << endl;
    file6 << "set xrange[" << xmin << ":" << xmax << "]" << endl;
    file6 << "set yrange[" << ymin << ":" << ymax << "]" << endl;
    file6 << "set zrange[" << zmin << ":" << zmax << "]" << endl;
    file6 << "imax=" << 5*Nx << endl;
    file6 << "i=0" << endl;
    file6 << "load \"script2.gnu\" ";
    file6.close();
    
    ofstream file7("script2.gnu");
    file7 << "set dgrid3d " << Nx << " , " << Ny << endl;
    file7 << "set pm3d at b" << endl;
    file7 << "set isosample 40,40" << endl;
    file7 << "splot \"point fixe 2D.txt\" index i with lines " << endl;
    file7 << "pause" << " " << 0.05 <<  endl;
    file7 << "i=i+1" << endl;
    file7 << "if (i<imax) reread" << endl;
    file7 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;


    system("gnuplot film2.gnuplot");

    ofstream file8("film2.gnuplot");
    //file8 << "set terminal x11" << endl;
    file8 << "set xrange[" << xmin << ":" << xmax << "]" << endl;
    file8 << "set yrange[" << ymin << ":" << ymax << "]" << endl;
    file8 << "set zrange[" << zmin << ":" << zmax << "]" << endl;
    file8 << "imax=" << 5*Nx << endl;
    file8 << "i=0" << endl;
    file8 << "load \"script2.gnu\" ";
    file8.close();
    
    ofstream file9("script2.gnu");
    file9 << "set dgrid3d " << Nx << " , " << Ny << endl;
    file9 << "set pm3d at b" << endl;
    file9 << "set isosample 40,40" << endl;
    file9 << "splot \"newton 2D.txt\" index i with lines " << endl;
    file9 << "pause" << " " << 0.05 <<  endl;
    file9 << "i=i+1" << endl;
    file9 << "if (i<imax) reread" << endl;
    file9 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;


    system("gnuplot film2.gnuplot");
    }


    // ---------------------------------------------------------------------
    // On stocke finalement dans les fichiers
    // Nous ne commentons pas chaque fichier stocké, les calculs
    // se font rapidement

    // Dimension 1
    alpha=10.0;
    deb=init_1d(Nx);
    P1=solvepfixe_1d(deb,T,omega,delta_t, D,alpha, "point fixe 1D 10.txt");
    deb=init_1d(Nx);
    N1=solvenew_1d(deb,T,delta_t,D,alpha,"newton 1D 10.txt");

    alpha=0.0;
    deb=init_1d(Nx);
    P1=solvepfixe_1d(deb,T,omega,delta_t, D,alpha, "point fixe 1D 0.txt");
    deb=init_1d(Nx);
    N1=solvenew_1d(deb,T,delta_t,D,alpha,"newton 1D 0.txt");

    alpha=20.0;
    deb=init_1d(Nx);
    P1=solvepfixe_1d(deb,T,omega,delta_t, D,alpha, "point fixe 1D 20.txt");
    deb=init_1d(Nx);
    N1=solvenew_1d(deb,T,delta_t,D,alpha,"newton 1D 20.txt");

    alpha=50.0;
    deb=init_1d(Nx);
    P1=solvepfixe_1d(deb,T,omega,delta_t, D,alpha, "point fixe 1D 50.txt");
    deb=init_1d(Nx);
    N1=solvenew_1d(deb,T,delta_t,D,alpha,"newton 1D 50.txt");

    alpha=100.0;
    deb=init_1d(Nx);
    P1=solvepfixe_1d(deb,T,omega,delta_t, D,alpha, "point fixe 1D 100.txt");
    deb=init_1d(Nx);
    N1=solvenew_1d(deb,T,delta_t,D,alpha,"newton 1D 100.txt");

    alpha=200.0;
    deb=init_1d(Nx);
    P1=solvepfixe_1d(deb,T,omega,delta_t, D,alpha, "point fixe 1D 200.txt");
    deb=init_1d(Nx);
    N1=solvenew_1d(deb,T,delta_t,D,alpha,"newton 1D 200.txt");

    // Dimension 2

    beta=1.0;
    BEG=init_2d(Nx,Ny);
    PF=solvepfixe_2d(BEG,T,omega,delta_t,D,beta,"point fixe 2D 1.txt");
    BEG=init_2d(Nx,Ny);
    NE=solvenew_2d(BEG,T,delta_t,D,beta, "newton 2D 1.txt");

    beta=0.0;
    BEG=init_2d(Nx,Ny);
    PF=solvepfixe_2d(BEG,T,omega,delta_t,D,beta,"point fixe 2D 0.txt");
    BEG=init_2d(Nx,Ny);
    NE=solvenew_2d(BEG,T,delta_t,D,beta, "newton 2D 0.txt");

    beta=2.0;
    BEG=init_2d(Nx,Ny);
    PF=solvepfixe_2d(BEG,T,omega,delta_t,D,beta,"point fixe 2D 2.txt");
    BEG=init_2d(Nx,Ny);
    NE=solvenew_2d(BEG,T,delta_t,D,beta, "newton 2D 2.txt");

    beta=10.0;
    BEG=init_2d(Nx,Ny);
    PF=solvepfixe_2d(BEG,T,omega,delta_t,D,beta,"point fixe 2D 10.txt");
    BEG=init_2d(Nx,Ny);
    NE=solvenew_2d(BEG,T,delta_t,D,beta, "newton 2D 10.txt");

    beta=20.0;
    BEG=init_2d(Nx,Ny);
    PF=solvepfixe_2d(BEG,T,omega,delta_t,D,beta,"point fixe 2D 20.txt");
    BEG=init_2d(Nx,Ny);
    NE=solvenew_2d(BEG,T,delta_t,D,beta, "newton 2D 20.txt");

return 0;
}
