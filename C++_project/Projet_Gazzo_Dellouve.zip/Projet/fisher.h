// ==================================================
// ==           Par                                ==
// ==      Sandro Gazzo                            ==
// ==           Et                                 ==
// ==      Théo Dellouve                           ==
// ==================================================



#include <iostream>
#include <assert.h>
#include <math.h>
#include <string>
#include <fstream>
#include "matrice.h"
#define pi 3.141592653558979323846
using namespace std;

class fisher
{
    public:
    double sol_1d(double&); // fonction 1d 
    vecteur init_1d(double&); // initialisation de u0 1d
    vecteur gn_1d(vecteur&,vecteur&,double&,double&,double&); // création du vecteur Gn en 1d
    vecteur pointfixe_1d(vecteur&,vecteur&,double&,double&,double&,double&); // fait une itération du point fixe et pose le problème en 1d
    vecteur solvepfixe_1d(vecteur&, double&,double&, double&, double&, double&, const char*); //résoud point fixe en 1d
    vecteur deriveeg_1d(vecteur&,double&,double&,double&); // correspond à la dérivée de Gn en 1d
    vecteur newton_1d(vecteur&,double&,double&,double&); // fait une itération de newton et pose le problème en 1d
    vecteur solvenew_1d(vecteur&, double&,double&,double&,double&); // résoud  newton en 1d
    double sol_2d(double&, double&); // fonction 2d (ie deuxieme probleme) 
    matrice init_2d(double&, double&); // initialisation de u0 2d
    matrice gn_2d(matrice&,matrice&,double&,double&,double&);// création de la matrice Gn en 2d
    matrice pointfixe_2d(matrice&,matrice&, double&,double&,double&,double&); // fait une itération du point fixe et pose le problème en 2d
    matrice solvepfixe_2d(matrice& ,double& ,double&, double& , double& , double&,const char*);//résoud point fixe en 2d
    matrice deriveeg_2d(matrice&, double&, double&, double&); // correspond à la dérivée de Gn en 2d
    matrice newton_2d(matrice&,double&, double&, double&); // fait une itération de newton et pose le problème en 2d
    matrice solvenew_2d(matrice&,double&, double&, double&, double&, const char*);// résoud  newton en 2d
};

double sol_1d(double& x)
{
    return sin(pi*x);
}

vecteur init_1d(double& Nx)
{
    vecteur V(Nx-1);
    double delta_x=1/Nx;
    double x=delta_x; 
    for (size_t i = 1; i < Nx; i++) //applique la fonction élément par élément
    {
        V(i-1)=sol_1d(x);
        x=x+delta_x;
    }
    return V;
}

vecteur gn_1d(vecteur& Y, vecteur& U,double& delta_t, double& D, double& alpha)
{
    // Initialisation
    double nx=U.dim();
    vecteur V(nx);
    double delta_x=1/(nx+1);
    double dx2=pow(delta_x,2);


    // Ecriture du vecteur Gn
    V(0)=Y(0)-(delta_t/dx2)*D*(-2*Y(0)+Y(1))-alpha*delta_t*Y(0)*(1-Y(0))-U(0);
    for (int i = 1; i < nx-1; i++)
    {
        V(i)=Y(i)-(delta_t/dx2)*D*(Y(i-1)-2*Y(i)+Y(i+1))-alpha*delta_t*Y(i)*(1-Y(i))-U(i);
    }
    V(nx-1)=Y(nx-1)-(delta_t/dx2)*D*(-2*Y(nx-1)+Y(nx-2))-alpha*delta_t*Y(nx-1)*(1-Y(nx-1))-U(nx-1);
    return V;
}

vecteur pointfixe_1d(vecteur& Y, vecteur& U, double& omega, double& delta_t, double& D, double alpha)
{
    // Initialisation
    double nx=U.dim();
    vecteur G(nx), H(nx);
    vecteur PHI(nx), C(nx);
    double precision=pow(10,-10);
    double i_max=10;
    double i=0;

    G(0)=1; //permet de commencer la boucle while
    H=Y; // on conserve Y
    while(G.norm_infini()>precision && i<i_max)
    {
        G=gn_1d(H,U,delta_t,D,alpha); // on stocke la matrice Gn
        C=H-(omega*G); // point fixe avec relaxation
        H=C; // on affecte C à H
        i=i+1;
    }
    return C;
}


vecteur solvepfixe_1d(vecteur& U0,double& T,double& omega, double& delta_t, double& D, double& alpha,const char* Fichier)
{
    // Initialisation
    double nx=U0.dim();
    double ite=int(T/delta_t)+1;
    vecteur S(nx);
    double delta_x=1/(nx+1);

    // Ouverture fichier
    ofstream file(Fichier);

    S=U0;// on préserve U0
    for (int j = 0; j < nx; j++)
        {
            file << (j+1)*delta_x<< " "<< S(j)<< endl;
        }
    file<<endl<<endl;
    for (int i = 0; i < ite; i++) // noombre d'itérations nécessaires
    {
        S=U0; // on préserve U0
        S=pointfixe_1d(S,U0,omega, delta_t,D,alpha); // on résout une itération du point fixe
        for (int j = 0; j < nx; j++) 
        {
            file << (j+1)*delta_x<<" "<< S(j)<<endl;
        }
        U0=S; //"" U0 devient U1"
        file<<endl<<endl;
    }
    file.close();
    return S;
}



vecteur deriveeg_1d(vecteur& X, double& delta_t, double& D, double& alpha )
{
    // Initialisation
    double nx=X.dim();
    vecteur Y(nx);
    vecteur Z(nx);
    double delta_x=1/(nx+1);
    double dx2=pow(delta_x,2);
    
    // Dérivee de Gn 
    for (int j = 0; j < nx; j++)
        {
            Z(j)=1+(delta_t/dx2)*D*2-alpha*delta_t+2*delta_t*alpha*X(j);
        }
    return Z;
}

vecteur newton_1d(vecteur& X,double& delta_t, double& D, double& alpha )
{
    // Initialisation
    double nx=X.dim();
    vecteur G(nx),DG(nx);
    vecteur Z(nx);
    double i=0;
    double i_max=20;
    double precision=pow(10,-6);
    double res=1; //permet de commencer la boucle while

    Z=X; // On préserve X
    DG=deriveeg_1d(X,delta_t,D,alpha); // calcul de la dérivée (un seul suffit)
    while (res>precision && i<i_max)
    {
        G=gn_1d(X,X,delta_t,D,alpha); // on stocke Gn
        for (int j = 0; j < nx; j++)
        {        
            Z(j)=X(j)-(G(j)/DG(j)); //méthode de newton élément par élément
        }
        res=G.norm_infini();
        i=i+1;
        

    }
    return Z;
}

vecteur solvenew_1d(vecteur& U0,double& T, double& delta_t, double& D, double& alpha , const char* Fichier)
{
    // Initialisation
    double nx=U0.dim();
    double ite=int(T/delta_t)+1;
    vecteur S(nx);
    double delta_x=1/(nx+1);

    // Ouverture fichier
    ofstream file(Fichier);
    S=U0; // On préserve U0
    for (int j = 0; j < nx; j++) 
        {
            file << (j+1)*delta_x<< " "<< S(j)<< endl;
        }
    file<<endl<<endl;
    for (int i = 0; i < ite; i++) // nombre d'itération pour résoudre newton
    {
        S=U0; // on préserve U0
        S=newton_1d(S,delta_t,D,alpha); // on résout une itération de newton
        for (int j = 0; j < nx; j++) 
        {
            file << (j+1)*delta_x<< " "<< S(j)<<endl;
        }
        U0=S; //"" U0 devient U1"
        file<<endl<<endl;
    }
    file.close();
    return S;
}


double sol_2d(double& x, double& y)
{
    return exp(-pow((5*x-3),2))*exp(-pow((5*y-3),2));
}

matrice init_2d(double& Nx, double& Ny)
{
    matrice M(Nx-1,Ny-1);
    double delta_x=1/Nx;
    double delta_y=1/Ny;
    double x=delta_x; 
    double y=delta_y; 
    for (int i=1; i<Nx; i++) //applique la fonction élément par élément
    {
        for(int j=1; j<Ny; j++)
        {
            M[i-1](j-1)=sol_2d(x,y); 
            y=y+delta_y;
        }
        x=x+delta_x;
        y=delta_y;
    }
    return M;
}


matrice gn_2d(matrice& Z,matrice& U,double& delta_t, double& D,double& alpha)
{
    // Initialisation
    double nx=U.dim1();
    double ny=U.dim2();
    matrice M(nx,ny);
    double delta_x=1/(nx+1);
    double delta_y=1/(ny+1);
    double dx2=pow(delta_x,2);
    double dy2=pow(delta_y,2);

    // Ecriture de la matrice Gn
    M[0](0)=Z[0](0)+delta_t*D*(((2/dx2)+(2/dy2))*Z[0](0)-(1/dx2)*Z[1](0)-(1/dy2)*Z[0](1)) - alpha*delta_t*Z[0](0)*(1-Z[0](0))-U[0](0);
    for (int i = 1; i < nx-1; i++)
    {
        M[i](0)=Z[i](0)+delta_t*D*(-(1/dx2)*Z[i-1](0)+((2/dx2)+(2/dy2))*Z[i](0)-(1/dx2)*Z[i+1](0)-(1/dy2)*Z[i](1)) - alpha*delta_t*Z[i](0)*(1-Z[i](0))-U[i](0);
    }
    M[nx-1](0)=Z[nx-1](0)+delta_t*D*(-(1/dx2)*Z[nx-2](0)+((2/dx2)+(2/dy2))*Z[nx-1](0)-(1/dy2)*Z[nx-1](1)) - alpha*delta_t*Z[nx-1](0)*(1-Z[nx-1](0))-U[nx-1](0);
    

    for (int j = 1; j < ny-1; j++)
    {
        M[0](j)=Z[0](j)+delta_t*D*(-(1/dy2)*Z[0](j-1)+((2/dx2)+(2/dy2))*Z[0](j)-(1/dx2)*Z[1](j)-(1/dy2)*Z[0](j+1)) - alpha*delta_t*Z[0](j)*(1-Z[0](j))-U[0](j);
    for (int i = 1; i < nx-1; i++)
    {
        M[i](j)=Z[i](j)+delta_t*D*(-(1/dy2)*Z[i](j-1)-(1/dx2)*Z[i-1](j)+((2/dx2)+(2/dy2))*Z[i](j)-(1/dx2)*Z[i+1](j)-(1/dy2)*Z[i](j+1)) - alpha*delta_t*Z[i](j)*(1-Z[i](j))-U[i](j);
    }
    M[nx-1](j)=Z[nx-1](j)+delta_t*D*(-(1/dy2)*Z[nx-1](j-1)-(1/dx2)*Z[nx-2](j)+((2/dx2)+(2/dy2))*Z[nx-1](j)-(1/dy2)*Z[nx-1](j+1)) - alpha*delta_t*Z[nx-1](j)*(1-Z[nx-1](j))-U[nx-1](j);
    }

    
    M[0](ny-1)=Z[0](ny-1)+delta_t*D*(((2/dx2)+(2/dy2))*Z[0](ny-1)-(1/dx2)*Z[1](ny-1)-(1/dy2)*Z[0](ny-2)) - alpha*delta_t*Z[0](ny-1)*(1-Z[0](ny-1))-U[0](ny-1);
    for (int i = 1; i < nx-1; i++)
    {
        M[i](ny-1)=Z[i](ny-1)+delta_t*D*(-(1/dx2)*Z[i-1](ny-1)+((2/dx2)+(2/dy2))*Z[i](ny-1)-(1/dx2)*Z[i+1](ny-1)-(1/dy2)*Z[i](ny-2)) - alpha*delta_t*Z[i](ny-1)*(1-Z[i](ny-1))-U[i](ny-1);
    }
    M[nx-1](ny-1)=Z[nx-1](ny-1)+delta_t*D*(-(1/dx2)*Z[nx-2](ny-1)+((2/dx2)+(2/dy2))*Z[nx-1](ny-1)-(1/dy2)*Z[nx-1](ny-2)) - alpha*delta_t*Z[nx-1](ny-1)*(1-Z[nx-1](ny-1))-U[nx-1](ny-1);
    return M;
}



matrice pointfixe_2d(matrice& Z, matrice& U, double& omega, double& delta_t, double& D, double alpha)
{
    // Initialisation
    double nx=U.dim1();
    double ny=U.dim2();
    matrice G(nx,ny), H(nx,ny);
    matrice PHI(nx,ny), C(nx,ny);
    double precision=pow(10,-10);
    double i_max=10;
    double i=0;

    G[0](0)=1; //permet de commencer la boucle while
    H=Z; // on conserve Y
    while(G.norm_mat_inf()>precision && i<i_max)
    {
        G=gn_2d(H,U,delta_t,D,alpha); // on stocke la matrice Gn
        C=H-(omega*G); // point fixe avec relaxation
        H=C; // on affecte C à H
        i=i+1;
    }
    return C;
}

matrice solvepfixe_2d(matrice& U0,double& T,double& omega, double& delta_t, double& D, double& alpha,const char* Fichier)
{
    // Initialisation
    double nx=U0.dim1();
    double ny=U0.dim2();
    double ite=int(T/delta_t)+1;
    matrice S(nx,ny);
    double delta_x=1/(nx+1);
    double delta_y=1/(ny+1);

    // Ouverture fichier
    ofstream file(Fichier);
    S=U0; // on préserve U0
    for (int j = 0; j < nx; j++) 
        {
            for (int k = 0; k < ny; k++)
            {
                file << (j+1)*delta_x<< " "<< (k+1)*delta_y<< " "<< S[j](k)<< endl;
            }
        }
    file<<endl<<endl;
    for (int i = 0; i < ite; i++) // noombre d'itérations nécessaires
    {
        S=U0; // on préserve U0
        S=pointfixe_2d(S,U0,omega, delta_t,D,alpha); // on résout une itération du point fixe
        for (int j = 0; j < nx; j++) 
        {
            for (int k = 0; k < ny; k++)
            {
                file << (j+1)*delta_x<< " "<< (k+1)*delta_y<< " "<< S[j](k)<< endl;
            }
        }
        U0=S; //"" U0 devient U1"
        file<<endl<<endl;
    }
    file.close();
    return S;
}


matrice deriveeg_2d(matrice& X, double& delta_t, double& D, double& alpha )
{
    // Initialisation
    double nx=X.dim1();
    double ny=X.dim2();
    matrice Y(nx,ny);
    matrice Z(nx,ny);
    double delta_x=1/(nx+1);
    double delta_y=1/(ny+1);
    double dx2=pow(delta_x,2);
    double dy2=pow(delta_y,2);

    // Dérivee de Gn 
    for (int i=0; i<nx; i++)
        {
        for (int j = 0; j < ny; j++)
            {
                Z[i](j)=1+delta_t*D*((2/dx2)+(2/dy2))-alpha*delta_t+2*delta_t*alpha*X[i](j);
            }
        }
    return Z;
}


matrice newton_2d(matrice& X,double& delta_t, double& D, double& alpha )
{
    // Initialisation
    double nx=X.dim1();
    double ny=X.dim2();
    matrice G(nx,ny);
    matrice DG(nx,ny);
    matrice Z(nx,ny);
    double i=0;
    double i_max=20;
    double precision=pow(10,-6);
    double res=1; //permet de commencer la boucle while

    Z=X; // On préserve X
    DG=deriveeg_2d(X,delta_t,D,alpha); // calcul de la dérivée (un seul suffit)
    while (res>precision && i<i_max)
    {
        G=gn_2d(X,X,delta_t,D,alpha); // on stocke Gn
        for (int j = 0; j < nx; j++)
        {        
            for (int k = 0; k < ny; k++)
            {
                Z[j](k)=X[j](k)-(G[j](k)/DG[j](k)); //méthode de newton élément par élément
            }
        }
        res=G.norm_mat_inf();
        i=i+1;
    }
    return Z;
}




matrice solvenew_2d(matrice& U0,double& T, double& delta_t, double& D, double& alpha , const char* Fichier)
{
    // Initialisation
    double nx=U0.dim1();
    double ny=U0.dim2();
    double ite=int(T/delta_t)+1;
    matrice S(nx,ny);
    double delta_x=1/(nx+1);
    double delta_y=1/(ny+1);

    // Ouverture fichier
    ofstream file(Fichier);
    S=U0; // On préserve U0
    for (int j = 0; j < nx; j++) 
        {
            for (int k = 0; k < ny; k++)
            {
                file << (j+1)*delta_x<< " "<< (k+1)*delta_y<< " " << S[j](k)<< endl;
            }
        }
    file<<endl<<endl;
    for (int i = 0; i < ite; i++) // nombre d'itération pour résoudre newton
    {
        S=U0; // on préserve U0
        S=newton_2d(S,delta_t,D,alpha);// on résout une itération de newton
        for (int j = 0; j < nx; j++) 
        {
            for (int k = 0; k < ny; k++)
            {
            file << (j+1)*delta_x<< " "<< (k+1)*delta_y<< " "<< S[j](k)<< endl;
            }
        }
        U0=S; //"" U0 devient U1"
        file<<endl<<endl;
    }
    file.close();
    return S;
}
