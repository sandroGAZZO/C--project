// ==================================================
// ==           Par                                ==
// ==      Sandro Gazzo                            ==
// ==           Et                                 ==
// ==      Théo Dellouve                           ==
// ==================================================


#include <iostream>
#include "onde.h"
#include <fstream>
#include <cmath>
#include <sstream>
#include <string>
#include <assert.h>
#include <time.h>
using namespace std;

int main()
{
// --------------------- DONNEES ---------------------------------------


// choix=1 : pincement d'une corde de guitare
// choix=2 : frottement d'une corde de violon
// choix=3 : corde d'un piano frappée

double T=5.0; // temps final

int N=500; // Nombre de maille


// -----------------------------------------------------------------------
double CFL=0.9;
for (int choix=1; choix<4; choix++)
{
cout << "Les données suivantes ont été sélectionnées :" << endl;
cout << "    choix du cas à traiter :" << choix << endl;
cout << "        1 : pincement d'une corde de guitare" << endl;
cout << "        2 : frottement d'une corde de violon" << endl;
cout << "        3 : corde d'un piano frappée" << endl;
cout << "    nombres de maille :" << N << endl;
cout << "    temps final :" << T << endl;
cout << "    condition CFL :" << CFL << endl;
cout << "    le delta x :"<< 1.0/N << endl;
cout << endl;

// -------------------------- Stockages -----------------------------------
double delta_x=1.0/N;
double delta_t=CFL*pow(delta_x,2)/2;
// -------------------------- Applications --------------------------------



//  Dans un premier temps, nous allons tracer les graphiques pour chaque cas
//  mais avec une seule condition CFL. Nous aurions pu stocker directement les
//  fichiers, mais il y aurait fallu ouvrir beaucoup de file. Nous avons donc
//  préféré séparer le travail.


vecteur S;
S=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite","EE L2","EE L_inf"); 

vecteur Imp;
Imp=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite", "EI L2","EI L_inf");

vecteur CN;
CN=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson", "CN L2", "CN L_inf","Energie");
// -------------------------- Graphique -----------------------------------

    //parametre pour gnuplot
    double xi,yi;
    double temps;

    //fenetre sur l'ordonné
    double ymin=-1.5;
    double ymax=1.5;

    //fenetre sur l'abscisse
    double xmin=0.0;
    double xmax=1.0;


    // On trace l'évolution en temps:

    ofstream file2("film1.gnuplot");
    //file2 << "set terminal x11" << endl;
    file2 << "set xrange[" << xmin << ":" << xmax << "]" << endl; //fenetre sur l'abscisse
    file2 << "set yrange[" << ymin << ":" << ymax << "]" << endl; //fenetre sur l'ordonné
    file2 << "imax=" << 4*N << endl; 
    file2 << "i=0" << endl;
    file2 << "load \"script1.gnu\" ";
    file2.close();

    ofstream file3("script1.gnu");
    file3 << "plot \"Euler Explicite\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file3 << "pause" << " " << 0.005 <<  endl;
    file3 << "i=i+10"<< endl;
    file3 << "if (i<imax) reread" << endl;
    file3 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot");

    ofstream file4("film1.gnuplot");
    //file4 << "set terminal x11" << endl;
    file4 << "set xrange[" << xmin << ":" << xmax << "]" << endl; //fenetre sur l'abscisse
    file4 << "set yrange[" << ymin << ":" << ymax << "]" << endl; //fenetre sur l'ordonné
    file4 << "imax=" << 4*N << endl; 
    file4 << "i=0" << endl;
    file4 << "load \"script1.gnu\" ";
    file4.close();


    ofstream file5("script1.gnu");
    file5 << "plot \"Euler Implicite\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file5 << "pause" << " " << 0.005 <<  endl;
    file5 << "i=i+10"<< endl;
    file5 << "if (i<imax) reread" << endl;
    file5 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot");

    ofstream file6("film1.gnuplot");
    //file6 << "set terminal x11" << endl;
    file6 << "set xrange[" << xmin << ":" << xmax << "]" << endl; //fenetre sur l'abscisse
    file6 << "set yrange[" << ymin << ":" << ymax << "]" << endl; //fenetre sur l'ordonné
    file6 << "imax=" << 4*N << endl; 
    file6 << "i=0" << endl;
    file6 << "load \"script1.gnu\" ";
    file6.close();


    ofstream file7("script1.gnu");
    file7 << "plot \"Crank-Nicolson\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file7 << "pause" << " " << 0.005 <<  endl;
    file7 << "i=i+10"<< endl;
    file7 << "if (i<imax) reread" << endl;
    file7 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot"); 

    double zmax=5.0;
    double zmin=0;
    double wmax=1.0;
    double wmin=0;

    // On trace les normes

    cout << "Norme L2"<<endl;

    ofstream file8("film1.gnuplot");
    //file8 << "set terminal x11" << endl;
    file8 << "set xrange[" << zmin << ":" << zmax << "]" << endl; //fenetre sur l'abscisse
    file8 << "set yrange[" << wmin << ":" << wmax << "]" << endl; //fenetre sur l'ordonné
    file8 << "imax=" << T << endl; 
    file8 << "i=0" << endl;
    file8 << "load \"script1.gnu\" ";
    file8.close();


    ofstream file9("script1.gnu");
    file9 << "plot \"EE L2\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file9 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot");

     ofstream file10("film1.gnuplot");
    //file10 << "set terminal x11" << endl;
    file10 << "set xrange[" << zmin << ":" << zmax << "]" << endl; //fenetre sur l'abscisse
    file10 << "set yrange[" << wmin << ":" << wmax << "]" << endl; //fenetre sur l'ordonné
    file10 << "imax=" << T << endl; 
    file10 << "i=0" << endl;
    file10 << "load \"script1.gnu\" ";
    file10.close();


    ofstream file11("script1.gnu");
    file11 << "plot \"EI L2\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file11 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot");


    ofstream file12("film1.gnuplot");
    //file12 << "set terminal x11" << endl;
    file12 << "set xrange[" << zmin << ":" << zmax << "]" << endl; //fenetre sur l'abscisse
    file12 << "set yrange[" << wmin << ":" << wmax << "]" << endl; //fenetre sur l'ordonné
    file12 << "imax=" << T << endl; 
    file12 << "i=0" << endl;
    file12 << "load \"script1.gnu\" ";
    file12.close();


    ofstream file13("script1.gnu");
    file13 << "plot \"CN L2\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file13 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot");

    cout << "Norme L infinie"<<endl;

    ofstream file14("film1.gnuplot");
    //file14 << "set terminal x11" << endl;
    file14 << "set xrange[" << zmin << ":" << zmax << "]" << endl; //fenetre sur l'abscisse
    file14 << "set yrange[" << wmin << ":" << wmax << "]" << endl; //fenetre sur l'ordonné
    file14 << "imax=" << T << endl; 
    file14 << "i=0" << endl;
    file14 << "load \"script1.gnu\" ";
    file14.close(); 


    ofstream file15("script1.gnu");
    file15 << "plot \"EE L_inf\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file15 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot");

    ofstream file16("film1.gnuplot");
    //file16 << "set terminal x11" << endl;
    file16 << "set xrange[" << zmin << ":" << zmax << "]" << endl; //fenetre sur l'abscisse
    file16 << "set yrange[" << wmin << ":" << wmax << "]" << endl; //fenetre sur l'ordonné
    file16 << "imax=" << T << endl; 
    file16 << "i=0" << endl;
    file16 << "load \"script1.gnu\" ";
    file16.close();


    ofstream file17("script1.gnu");
    file17 << "plot \"EI L_inf\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file17 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot");

    ofstream file18("film1.gnuplot");
    //file18 << "set terminal x11" << endl;
    file18 << "set xrange[" << zmin << ":" << zmax << "]" << endl; //fenetre sur l'abscisse
    file18 << "set yrange[" << wmin << ":" << wmax << "]" << endl; //fenetre sur l'ordonné
    file18 << "imax=" << T << endl; 
    file18 << "i=0" << endl;
    file18 << "load \"script1.gnu\" ";
    file18.close();


    ofstream file19("script1.gnu");
    file19 << "plot \"CN L_inf\" index i with linespoints pointtype 7 pointsize 1" << endl;
    file19 << "pause -1 \"Appuyer sur une touche pour terminer \" " << endl;

    system("gnuplot film1.gnuplot");

 }

// -------------------------------------------------------------------------
// Stockage des fichiers: ici on stocke les fichiers pour pouvoir les
// tracer sous python par la suite.


// Initialisation
CFL=1.2;
int choix=1;

vecteur explicite;
vecteur implicite;
vecteur cn;

// Stockage

cout << "CFL="<<CFL<<endl;
cout << "Choix 1 "<<endl;
explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 1 12.txt ","EE L2 1 12.txt","EE L_inf 1 12.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 1 12.txt", "EI L2 1 12.txt","EI L_inf 1 12.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 1 12.txt", "CN L2 1 12.txt", "CN L_inf 1 12.txt","Energie 1 12.txt");


choix=2;
cout <<"Choix 2 "<<endl;
explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 2 12.txt ","EE L2 2 12.txt","EE L_inf 2 12.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 2 12.txt", "EI L2 1 12.txt","EI L_inf 2 12.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 2 12.txt", "CN L2 2 12.txt", "CN L_inf 2 12.txt","Energie 2 12.txt");

choix=3;
cout <<"Choix 3 "<<endl;
explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 3 12.txt ","EE L2 3 12.txt","EE L_inf 3 12.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 3 12.txt", "EI L2 3 12.txt","EI L_inf 3 12.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 3 12.txt", "CN L2 3 12.txt", "CN L_inf 3 12.txt","Energie 3 12.txt");

CFL=1.0;
choix=1;

cout << "CFL="<<CFL<<endl;
cout << "Choix 1 "<<endl;

explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 1 10.txt ","EE L2 1 10.txt","EE L_inf 1 10.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 1 10.txt", "EI L2 1 10.txt","EI L_inf 1 10.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 1 10.txt", "CN L2 1 10.txt", "CN L_inf 1 10.txt","Energie 1 10.txt");

choix=2;
cout <<"Choix 2 "<<endl;
explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 2 10.txt ","EE L2 2 10.txt","EE L_inf 2 10.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 2 10.txt", "EI L2 1 10.txt","EI L_inf 2 10.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 2 10.txt", "CN L2 2 10.txt", "CN L_inf 2 10.txt","Energie 2 10.txt");

choix=3;
cout <<"Choix 3 "<<endl;
explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 3 10.txt ","EE L2 3 10.txt","EE L_inf 3 10.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 3 10.txt", "EI L2 3 10.txt","EI L_inf 3 10.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 3 10.txt", "CN L2 3 10.txt", "CN L_inf 3 10.txt","Energie 3 10.txt");

CFL=0.9;
choix=1;

cout << "CFL="<<CFL<<endl;
cout << "Choix 1 "<<endl;

explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 1 09.txt ","EE L2 1 09.txt","EE L_inf 1 09.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 1 09.txt", "EI L2 1 09.txt","EI L_inf 1 09.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 1 09.txt", "CN L2 1 09.txt", "CN L_inf 1 09.txt","Energie 1 09.txt");


choix=2;
cout <<"Choix 2 "<<endl;

explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 2 09.txt ","EE L2 2 09.txt","EE L_inf 2 09.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 2 09.txt", "EI L2 1 09.txt","EI L_inf 2 09.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 2 09.txt", "CN L2 2 09.txt", "CN L_inf 2 09.txt","Energie 2 09.txt");

choix=3;
cout <<"Choix 3 "<<endl;

explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 3 09.txt ","EE L2 3 09.txt","EE L_inf 3 09.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 3 09.txt", "EI L2 3 09.txt","EI L_inf 3 09.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 3 09.txt", "CN L2 3 09.txt", "CN L_inf 3 09.txt","Energie 3 09.txt");

CFL=0.5;
choix=1;

cout << "CFL="<<CFL<<endl;
cout << "Choix 1 "<<endl;

explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 1 05.txt ","EE L2 1 05.txt","EE L_inf 1 05.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 1 05.txt", "EI L2 1 05.txt","EI L_inf 1 05.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 1 05.txt", "CN L2 1 05.txt", "CN L_inf 1 05.txt","Energie 1 05.txt");


choix=2;
cout <<"Choix 2 "<<endl;

explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 2 05.txt ","EE L2 2 05.txt","EE L_inf 2 05.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 2 05.txt", "EI L2 1 05.txt","EI L_inf 2 05.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 2 05.txt", "CN L2 2 05.txt", "CN L_inf 2 05.txt","Energie 2 05.txt");

choix=3;
cout <<"Choix 3 "<<endl;

explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 3 05.txt ","EE L2 3 05.txt","EE L_inf 3 05.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 3 05.txt", "EI L2 3 05.txt","EI L_inf 3 05.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 3 05.txt", "CN L2 3 05.txt", "CN L_inf 3 05.txt","Energie 3 05.txt");


CFL=0.1;
choix=1;

cout << "CFL="<<CFL<<endl;
cout << "Choix 1 "<<endl;

explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 1 01.txt ","EE L2 1 01.txt","EE L_inf 1 01.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 1 01.txt", "EI L2 1 01.txt","EI L_inf 1 01.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 1 01.txt", "CN L2 1 01.txt", "CN L_inf 1 01.txt","Energie 1 01.txt");


choix=2;
cout <<"Choix 2 "<<endl;

explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 2 01.txt ","EE L2 2 01.txt","EE L_inf 2 01.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 2 01.txt", "EI L2 1 01.txt","EI L_inf 2 01.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 2 01.txt", "CN L2 2 01.txt", "CN L_inf 2 01.txt","Energie 2 01.txt");

choix=3;
cout <<"Choix 3 "<<endl;

explicite=ondes_euler_explicite(T,CFL,N,choix, "Euler Explicite 3 01.txt ","EE L2 3 01.txt","EE L_inf 3 01.txt"); 

implicite=ondes_euler_implicite(T,CFL,N,choix, "Euler Implicite 3 01.txt", "EI L2 3 01.txt","EI L_inf 3 01.txt");

cn=ondes_crank_nicolson(T,CFL,N,choix, "Crank-Nicolson 3 01.txt", "CN L2 3 01.txt", "CN L_inf 3 01.txt","Energie 3 01.txt");

// -------------------------------------------------------------------------
// Ici, on va stocker les vecteurs erreurs en fonction de chaque fonction 
// par rapport à la solution exacte par rapport à la norme L2.


// Initialisation
choix=4;
CFL=0.9;

vecteur erreur_ee(7);
vecteur erreur_ei(7);
vecteur erreur_cn(7);

vecteur leN(7);
leN(0)=8;
leN(1)=16;
leN(2)=32;
leN(3)=64;
leN(4)=128;
leN(5)=256;
leN(6)=512;

cout << "Stockage Erreur"<<endl;

// Stockage vecteur
for (int i = 0; i < 7; i++)
{
    N=leN(i);
    vecteur solex(N+1);
vecteur solap_ee(N+1);
vecteur solap_ei(N+1);
vecteur solap_cn(N+1);


solex=solexacte(T,N);

solap_ee=ondes_euler_explicite(T,CFL,N,choix,"EE erreur.txt","EE erreur L2.txt","EE erreur L_inf");
erreur_ee(i)=(solex-solap_ee).norm_2();

solap_ei=ondes_euler_implicite(T,CFL,N,choix,"EI erreur.txt","EI erreur L2.txt","EI erreur L_inf");
erreur_ei(i)=(solex-solap_ei).norm_2();

solap_cn=ondes_crank_nicolson(T,CFL,N,choix,"CN erreur.txt","CN erreur L2.txt","CN erreur L_inf","Energie Erreur");
erreur_cn(i)=(solex-solap_cn).norm_2();

}


// Ecriture dans les fichiers
ofstream file82("Erreur EE.txt");
ofstream file84("Erreur EI.txt");
ofstream file86("Erreur CN.txt");

for (int i = 0; i < 7; i++)
{
    file82 << leN(i)<<" "<<erreur_ee(i)<<endl;
    file84 << leN(i) << " "<<erreur_ei(i)<<endl;
    file86 << leN(i)<< " "<<erreur_cn(i)<<endl;
}

file86.close();
file84.close();
file82.close();

// Fin du  programme

return 0;
}