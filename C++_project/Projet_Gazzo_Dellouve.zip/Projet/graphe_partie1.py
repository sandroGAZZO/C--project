import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from mpl_toolkits.mplot3d import Axes3D

#%%

f1 = open("CN L_inf 1 12.txt", "r")
f2 = open("CN L_inf 1 10.txt", "r")
f3 = open("CN L_inf 1 09.txt", "r")
f4 = open("CN L_inf 1 05.txt", "r")
f5 = open("CN L_inf 1 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")


plt.title("Norme infini de la solution pour CN pour la guitare")
plt.xlabel("t")
plt.ylabel("norme infini")
plt.legend(loc=3)
plt.show()

f1 = open("CN L2 1 12.txt", "r")
f2 = open("CN L2 1 10.txt", "r")
f3 = open("CN L2 1 09.txt", "r")
f4 = open("CN L2 1 05.txt", "r")
f5 = open("CN L2 1 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)


plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")


plt.title("Norme L2 de la solution pour CN pour la guitare")
plt.xlabel("t")
plt.ylabel("norme L2")
plt.legend(loc=3)
plt.show()

#%%

f1 = open("CN L_inf 2 12.txt", "r")
f2 = open("CN L_inf 2 10.txt", "r")
f3 = open("CN L_inf 2 09.txt", "r")
f4 = open("CN L_inf 2 05.txt", "r")
f5 = open("CN L_inf 2 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")


plt.title("Norme infini de la solution pour CN pour le violon")
plt.xlabel("t")
plt.ylabel("norme infini")
plt.legend(loc=3)
plt.show()

f1 = open("CN L2 2 12.txt", "r")
f2 = open("CN L2 2 10.txt", "r")
f3 = open("CN L2 2 09.txt", "r")
f4 = open("CN L2 2 05.txt", "r")
f5 = open("CN L2 2 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")


plt.title("Norme L2 de la solution pour CN pour le violon")
plt.xlabel("t")
plt.ylabel("norme L2")
plt.legend(loc=3)
plt.show()

#%%

f1 = open("CN L_inf 3 12.txt", "r")
f2 = open("CN L_inf 3 10.txt", "r")
f3 = open("CN L_inf 3 09.txt", "r")
f4 = open("CN L_inf 3 05.txt", "r")
f5 = open("CN L_inf 3 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.title("Norme infini de la solution pour CN pour le piano")
plt.xlabel("t")
plt.ylabel("norme infini")
plt.legend(loc=3)
plt.show()

f1 = open("CN L2 3 12.txt", "r")
f2 = open("CN L2 3 10.txt", "r")
f3 = open("CN L2 3 09.txt", "r")
f4 = open("CN L2 3 05.txt", "r")
f5 = open("CN L2 3 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")


plt.title("Norme L2 de la solution pour CN pour le piano")
plt.xlabel("t")
plt.ylabel("norme L2")
plt.legend(loc=3)
plt.show()

#%%

f1 = open("EE L_inf 1 12.txt", "r")
f2 = open("EE L_inf 1 10.txt", "r")
f3 = open("EE L_inf 1 09.txt", "r")
f4 = open("EE L_inf 1 05.txt", "r")
f5 = open("EE L_inf 1 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0.1,1.2)

plt.title("Norme infini de la solution pour EE pour la guitare")
plt.xlabel("t")
plt.ylabel("norme infini")
plt.legend(loc=3)
plt.show()

f1 = open("EE L2 1 12.txt", "r")
f2 = open("EE L2 1 10.txt", "r")
f3 = open("EE L2 1 09.txt", "r")
f4 = open("EE L2 1 05.txt", "r")
f5 = open("EE L2 1 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0.1,0.8)

plt.title("Norme L2 de la solution pour EE pour la guitare")
plt.xlabel("t")
plt.ylabel("norme L2")
plt.legend(loc=3)
plt.show()

#%%

f1 = open("EE L_inf 2 12.txt", "r")
f2 = open("EE L_inf 2 10.txt", "r")
f3 = open("EE L_inf 2 09.txt", "r")
f4 = open("EE L_inf 2 05.txt", "r")
f5 = open("EE L_inf 2 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0,1.5)

plt.title("Norme infini de la solution pour EE pour le violon")
plt.xlabel("t")
plt.ylabel("norme infini")
plt.legend(loc=3)
plt.show()

f1 = open("EE L2 2 12.txt", "r")
f2 = open("EE L2 2 10.txt", "r")
f3 = open("EE L2 2 09.txt", "r")
f4 = open("EE L2 2 05.txt", "r")
f5 = open("EE L2 2 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)


plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0,1)

plt.title("Norme L2 de la solution pour EE pour le violon")
plt.xlabel("t")
plt.ylabel("norme L2")
plt.legend(loc=3)
plt.show()

#%%

f1 = open("EE L_inf 3 12.txt", "r")
f2 = open("EE L_inf 3 10.txt", "r")
f3 = open("EE L_inf 3 09.txt", "r")
f4 = open("EE L_inf 3 05.txt", "r")
f5 = open("EE L_inf 3 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0,1.5)

plt.title("Norme infini de la solution pour EE pour le piano")
plt.xlabel("t")
plt.ylabel("norme infini")
plt.legend(loc=3)
plt.show()

f1 = open("EE L2 3 12.txt", "r")
f2 = open("EE L2 3 10.txt", "r")
f3 = open("EE L2 3 09.txt", "r")
f4 = open("EE L2 3 05.txt", "r")
f5 = open("EE L2 3 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.ylim(0,1.5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.title("Norme L2 de la solution pour EE pour le piano")
plt.xlabel("t")
plt.ylabel("norme L2")
plt.legend(loc=3)
plt.show()

#%%

f1 = open("EI L_inf 1 12.txt", "r")
f2 = open("EI L_inf 1 10.txt", "r")
f3 = open("EI L_inf 1 09.txt", "r")
f4 = open("EI L_inf 1 05.txt", "r")
f5 = open("EI L_inf 1 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0.1,1.2)

plt.title("Norme infini de la solution pour EI pour la guitare")
plt.xlabel("t")
plt.ylabel("norme infini")
plt.legend(loc=3)
plt.show()

f1 = open("EI L2 1 12.txt", "r")
f2 = open("EI L2 1 10.txt", "r")
f3 = open("EI L2 1 09.txt", "r")
f4 = open("EI L2 1 05.txt", "r")
f5 = open("EI L2 1 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0.1,0.8)

plt.title("Norme L2 de la solution pour EI pour la guitare")
plt.xlabel("t")
plt.ylabel("norme L2")
plt.legend(loc=3)
plt.show()

#%%

f1 = open("EI L_inf 2 12.txt", "r")
f2 = open("EI L_inf 2 10.txt", "r")
f3 = open("EI L_inf 2 09.txt", "r")
f4 = open("EI L_inf 2 05.txt", "r")
f5 = open("EI L_inf 2 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0,1.5)

plt.title("Norme infini de la solution pour EI pour le violon")
plt.xlabel("t")
plt.ylabel("norme infini")
plt.legend(loc=3)
plt.show()

f1 = open("EI L2 2 12.txt", "r")
f2 = open("EI L2 2 10.txt", "r")
f3 = open("EI L2 2 09.txt", "r")
f4 = open("EI L2 2 05.txt", "r")
f5 = open("EI L2 2 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)


plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0,1)

plt.title("Norme L2 de la solution pour EI pour le violon")
plt.xlabel("t")
plt.ylabel("norme L2")
plt.legend(loc=3)
plt.show()
#%%

f1 = open("EI L_inf 3 12.txt", "r")
f2 = open("EI L_inf 3 10.txt", "r")
f3 = open("EI L_inf 3 09.txt", "r")
f4 = open("EI L_inf 3 05.txt", "r")
f5 = open("EI L_inf 3 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)

plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0,1.5)

plt.title("Norme infini de la solution pour EI pour le piano")
plt.xlabel("t")
plt.ylabel("norme infini")
plt.legend(loc=3)
plt.show()

f1 = open("EI L2 3 12.txt", "r")
f2 = open("EI L2 3 10.txt", "r")
f3 = open("EI L2 3 09.txt", "r")
f4 = open("EI L2 3 05.txt", "r")
f5 = open("EI L2 3 01.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)


plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.plot(c3[:,0],c3[:,1],label="CFL=0.9")
plt.plot(c4[:,0],c4[:,1],label="CFL=0.5")
plt.plot(c5[:,0],c5[:,1],label="CFL=0.1")

plt.ylim(0,1)

plt.title("Norme L2 de la solution pour EI pour le piano")
plt.xlabel("t")
plt.ylabel("norme L2")
plt.legend(loc=3)
plt.show()


#%%

f1 = open("Energie 1 12.txt", "r")
f2 = open("Energie 1 10.txt", "r")
f3 = open("Energie 2 12.txt", "r")
f4 = open("Energie 2 10.txt", "r")
f5 = open("Energie 3 12.txt", "r")
f6 = open("Energie 3 10.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)
c4=np.loadtxt(f4)
c5=np.loadtxt(f5)
c6=np.loadtxt(f6)


plt.plot(c1[:,0],c1[:,1],label="CFL=1.2")
plt.title("Energie pour la guitar avec CFL=1.2")
plt.xlabel("t")
plt.ylabel("energie")
plt.show()

plt.plot(c2[:,0],c2[:,1],label="CFL=1.0")
plt.title("Energie pour la guitar avec CFL=1.0")
plt.xlabel("t")
plt.ylabel("energie")
plt.show()

plt.plot(c3[:,0],c3[:,1],label="CFL=1.2")
plt.title("Energie pour le violon avec CFL=1.2")
plt.xlabel("t")
plt.ylabel("energie")
plt.show()

plt.plot(c4[:,0],c4[:,1],label="CFL=1.0")
plt.title("Energie pour le violon avec CFL=1.0")
plt.xlabel("t")
plt.ylabel("energie")
plt.show()

plt.plot(c5[:,0],c5[:,1],label="CFL=1.2")
plt.title("Energie pour le piano avec CFL=1.2")
plt.xlabel("t")
plt.ylabel("energie")
plt.show()

plt.plot(c6[:,0],c6[:,1],label="CFL=1.0")
plt.title("Energie pour le piano avec CFL=1.0")
plt.xlabel("t")
plt.ylabel("energie")
plt.show()

#%%

# question 6 : erreur

f1 = open("Erreur CN.txt", "r")
f2 = open("Erreur EE.txt", "r")
f3 = open("Erreur EI.txt", "r")
c1=np.loadtxt(f1)
c2=np.loadtxt(f2)
c3=np.loadtxt(f3)

plt.loglog(c1[:,0],c1[:,1],'o')
plt.title("mise en évidence de l'odre de convergence pour CN")
plt.xlabel("log N")
plt.ylabel("log erreur")
plt.show()

plt.loglog(c2[:,0],c2[:,1],'o')
plt.title("mise en évidence de l'odre de convergence pour EE")
plt.xlabel("log N")
plt.ylabel("log erreur")
plt.show()

plt.loglog(c3[:,0],c3[:,1],'o')
plt.title("mise en évidence de l'odre de convergence pour EI")
plt.xlabel("log N")
plt.ylabel("log erreur")
plt.show()

#%%

print((np.log(c1[6,1])-np.log(c1[1,1]))/(np.log(c1[5,0])-np.log(c1[5,0])))

print((np.log(c2[6,1])-np.log(c2[0,1]))/(np.log(c2[6,0])-np.log(c2[0,0])))

print((np.log(c3[6,1])-np.log(c3[0,1]))/(np.log(c3[6,0])-np.log(c3[0,0])))